#!/usr/bin/env python3
# This is the file where should insert your own code.
#
# Author: Your Name <your@email.com>


# For exercise 1.2
def evaluate_energy(nodes, edges, assignment):
    return 0.0


# For exercise 1.3
def bruteforce(nodes, edges):
    assignment = [0] * len(nodes)
    # TODO: implement brute-force algorithm here...
    energy = evaluate_energy(node, edges, assignment)
    return (assignment, energy)


# For exercise 1.4
def dynamic_programming(nodes, edges):
    F, ptr = None, None
    return F, ptr

def backtrack(nodes, edges, F, ptr):
    assignment = [0] * len(nodes)
    return assignment


# For exercise 1.5
def compute_min_marginals(nodes, edges):
    m = [[0 for l in n] for n in nodes]
    return m


# For execrise 1.6
def dynamic_programming_tree(nodes, edges):
    F, ptr = None, None
    return F, ptr

def backtrack_tree(nodes, edges, F, ptr):
    assignment = [0] * len(nodes)
    return assignment
